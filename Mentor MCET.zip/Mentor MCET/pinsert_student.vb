﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class pinsert_student
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim result As Integer
    Dim imgpath As String
    Dim arrImage() As Byte
    Dim sql As String

    Private Sub pinsert_student_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.AutoScroll = True
        Try
            cn = New MySqlConnection

            With cn
                .ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000;pooling=true"
                .Open()
                .Close()

            End With

        Catch ex As Exception
            MsgBox(ex.Message & "Unable to connect. please contact the system administrator!", vbExclamation)
            cn.Close()
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Dim OFD As FileDialog = New OpenFileDialog()

            OFD.Filter = "Image File (*.jpg;*bmp;*.gif;*.img)|*.jpg;*bmp;*.gif;*.img"

            If OFD.ShowDialog() = DialogResult.OK Then
                imgpath = OFD.FileName
                PictureBox1.ImageLocation = imgpath

            End If

            OFD = Nothing

        Catch ex As Exception
            MsgBox(ex.Message.ToString())
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        student_details.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
                cn.Open()
                cm = New MySqlCommand("INSERT INTO student_details ( name , roll_no , degree_branch, batch, dob, place_of_birth, first_graduate, tc_no, mother_tongue, relegion, photo, section, cut_off_mark, admission_no, date_of_joining,category, tc_date, community, ph_no, identification_marks, communication_address , mail_id , father_name , father_occupation , father_ph_no, mother_name , mother_ph_no , annual_income ) values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.SelectedItem & "','" & ComboBox2.SelectedItem & "','" & DateTimePicker1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "',@photo,'" & TextBox8.Text & "','" & TextBox9.Text & "','" & TextBox10.Text & "','" & DateTimePicker2.Text & "','" & ComboBox3.SelectedItem & "','" & DateTimePicker3.Text & "','" & TextBox11.Text & "','" & TextBox12.Text & "','" & RichTextBox1.Text & "' , '" & RichTextBox2.Text & "' ,'" & TextBox13.Text & "','" & TextBox14.Text & "','" & TextBox15.Text & "','" & TextBox16.Text & "', '" & TextBox17.Text & "', '" & TextBox18.Text & "', '" & TextBox19.Text & "')", cn)
                cm.Parameters.AddWithValue("@photo", File.ReadAllBytes(imgpath))
                cm.ExecuteNonQuery()


                MsgBox("Details have Registered Successfully", vbInformation)

            TextBox1.Clear()
            TextBox2.Clear()
            ComboBox1.ResetText()
            ComboBox2.ResetText()

            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
            TextBox8.Clear()
            TextBox9.Clear()
            TextBox10.Clear()
            RichTextBox1.Clear()
            RichTextBox2.Clear()

            ComboBox3.ResetText()

            TextBox12.Clear()
            TextBox13.Clear()
            TextBox14.Clear()
            TextBox15.Clear()
            TextBox16.Clear()
            TextBox17.Clear()
            TextBox18.Clear()
            TextBox19.Clear()


            cn.Close()
        Catch ex As Exception
            cn.Close()
            MsgBox(ex.Message, vbCritical)

        End Try
    End Sub

  
End Class