﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class oinsert_student
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim result As Integer

    Private Sub oinsert_student_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            cn = New MySqlConnection
            cm = New MySqlCommand
            
        Catch ex As Exception
            MsgBox(ex.Message & "Unable to connect. please contact the system administrator!", vbExclamation)
            cn.Close()
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        student_details.Show()
        Me.Close()

    End Sub

 

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        personal_counselling.Show()
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        residential_status.Show()
        Me.Close()

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        extra_curricular_activities.Show()
        Me.Close()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        interaction_with_parents.Show()
        Me.Close()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        co_curricular_activities.Show()
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        disciplinary_action.Show()
        Me.Close()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        leave_od_details.Show()
        Me.Close()

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        academic_performance_insert.Show()
        Me.Close()

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        academic_performance_update.Show()
        Me.Close()

    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        academic_performance_delete.Show()
        Me.Close()

    End Sub

    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        academic_performance_view.Show()
        Me.Close()
    End Sub
End Class