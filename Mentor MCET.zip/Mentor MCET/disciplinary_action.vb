﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class disciplinary_action
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim result As Integer
    Dim imgpath As String
    Dim arrImage() As Byte
    Dim sql As String

    Private Sub disciplinary_action_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New MySqlConnection
        cm = New MySqlCommand
        cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
        cn.Open()
        cm.Connection = cn
        cm.CommandText = "select roll_no from student_details"
        dr = cm.ExecuteReader
        While dr.Read
            ComboBox1.Items.Add(dr.GetString(0))
        End While
        dr.Close()
        cn.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        oinsert_student.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            cn.Open()
            cm = New MySqlCommand("INSERT INTO `disciplinary_action`(`roll_no`, `s_no`, `date`,  `description`, `remarks`) VALUES ('" & ComboBox1.SelectedItem & "', '" & TextBox1.Text & "' ,'" & DateTimePicker1.Text & "', '" & RichTextBox1.Text & "',  '" & RichTextBox2.Text & "' )", cn)
            cm.ExecuteNonQuery()

            MsgBox("Details have Registered Successfully", vbInformation)
            ComboBox1.ResetText()
            TextBox1.Clear()

            RichTextBox1.Clear()
            RichTextBox2.Clear()

            cn.Close()
        Catch ex As Exception
            cn.Close()
            MsgBox(ex.Message, vbCritical)

        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            cn = New MySqlConnection
            cm = New MySqlCommand
            cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
            cn.Open()

            cm.CommandText = " UPDATE `disciplinary_activities` SET date = '" & DateTimePicker1.Text & "', description= '" & RichTextBox1.Text & "' , remarks = '" & RichTextBox2.Text & "'  WHERE roll_no = '" & ComboBox1.SelectedItem & "' and s_no = '" & TextBox1.Text & "'"
            cm.Connection = cn
            cm.ExecuteNonQuery()

            MsgBox("Details have Updated Successfully", vbInformation)
            ComboBox1.ResetText()
            TextBox1.Clear()

            RichTextBox1.Clear()
            RichTextBox2.Clear()
            cn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cn.Dispose()

        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try
            cn = New MySqlConnection
            cm = New MySqlCommand
            cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
            cn.Open()

            cm.CommandText = "DELETE FROM `disciplinary_action` WHERE  roll_no = '" & ComboBox1.SelectedItem & "' and s_no = '" & TextBox1.Text & "'"

            cm.Connection = cn
            cm.ExecuteNonQuery()

            MsgBox("Details have Deleted Successfully", vbInformation)
            ComboBox1.ResetText()
            TextBox1.Clear()

            RichTextBox1.Clear()
            RichTextBox2.Clear()

            cn.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cn.Dispose()

        End Try
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        cn = New MySqlConnection
        cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
        Dim da As New MySqlDataAdapter
        Dim dt As New DataTable
        Dim bsource As New BindingSource
        Try
            cn.Open()
            Dim Query As String
            Query = "SELECT * FROM `disciplinary_action` WHERE `roll_no` = '" & ComboBox1.SelectedItem & "'  "
            cm = New MySqlCommand(Query, cn)
            da.SelectCommand = cm
            da.Fill(dt)
            bsource.DataSource = dt
            DataGridView1.DataSource = bsource
            da.Update(dt)

            cn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cn.Dispose()

        End Try
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        SaveFileDialog1.ShowDialog()
        TextBox3.Text = SaveFileDialog1.FileName
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim xlApp As Microsoft.Office.Interop.Excel.Application
        Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
        Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer
        xlApp = New Microsoft.Office.Interop.Excel.Application
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = xlWorkBook.Sheets("sheet1")
        For i = 0 To DataGridView1.RowCount - 2
            For j = 0 To DataGridView1.ColumnCount - 1
                For k As Integer = 1 To DataGridView1.Columns.Count
                    xlWorkSheet.Cells(1, k) = DataGridView1.Columns(k - 1).HeaderText
                    xlWorkSheet.Cells(i + 2, j + 1) = DataGridView1(j, i).Value.ToString()
                Next
            Next
        Next
        xlWorkSheet.SaveAs("" & TextBox3.Text & ".xlsx")
        xlWorkBook.Close()
        xlApp.Quit()
        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)
        MsgBox("The records are inserted successfully.View the File at this Location'" & TextBox3.Text & "'!!!")
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub
End Class