﻿Imports MySql.Data.MySqlClient

Public Class new_user
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader

    Private Sub new_user_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            cn = New MySqlConnection

            With cn
                .ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000;pooling=true"
                .Open()
                .Close()

            End With

        Catch ex As Exception
            MsgBox(ex.Message & "Unable to Connect. Please Contact the System Administrator!", vbExclamation)
            cn.Close()
        End Try

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        login.Show()
        Me.Close()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            cn.Open()
            cm = New MySqlCommand("INSERT INTO staff_login ( name , roll_no , dept , user_id, password, ph_no  ) values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "')", cn)
            cm.ExecuteNonQuery()

            MsgBox("Your User Account Registration is Successfull", vbInformation)
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()

            cn.Close()
        Catch ex As Exception
            cn.Close()
            MsgBox(ex.Message, vbCritical)

        End Try
    End Sub
 
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If TextBox6.UseSystemPasswordChar = True Then
            ' show password

            TextBox6.UseSystemPasswordChar = False

        Else
            ' hide password
            TextBox6.UseSystemPasswordChar = True

        End If
    End Sub

   
End Class