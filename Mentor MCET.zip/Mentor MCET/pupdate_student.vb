﻿Imports MySql.Data.MySqlClient
Imports System.IO

Public Class pupdate_student
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim result As Integer
    Dim imgpath As String
    Dim arrImage() As Byte
    Dim sql As String
    Private Sub pupdate_student_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.AutoScroll = True
        Try
            cn = New MySqlConnection
            cm = New MySqlCommand
            cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
            cn.Open()
            cm.Connection = cn

                da = New MySqlDataAdapter("select * from student_details where roll_no='" & pupdate_student1.ComboBox1.SelectedItem & "' ", cn)
                ds = New Data.DataSet
                If da.Fill(ds, "student_details") Then
                    dv = New Data.DataView(ds.Tables("student_details"))
                    drv = dv(0)
                    TextBox1.Text = drv(0)
                    TextBox2.Text = drv(1)
                    ComboBox1.SelectedItem = drv(2)
                    ComboBox2.SelectedItem = drv(3)

                TextBox3.Text = drv(5)
                TextBox4.Text = drv(6)
                TextBox5.Text = drv(7)
                TextBox6.Text = drv(8)
                TextBox7.Text = drv(9)


                TextBox8.Text = drv(11)
                TextBox9.Text = drv(12)
                TextBox10.Text = drv(13)

                ComboBox3.SelectedItem = drv(15)

                TextBox11.Text = drv(17)
                TextBox12.Text = drv(18)
                RichTextBox1.Text = drv(19)
                RichTextBox2.Text = drv(20)
                TextBox13.Text = drv(21)
                TextBox14.Text = drv(22)
                TextBox15.Text = drv(23)
                TextBox16.Text = drv(24)
                TextBox17.Text = drv(25)
                TextBox18.Text = drv(26)
                TextBox19.Text = drv(27)

                End If
              

        Catch ex As Exception
            MsgBox(ex.Message & "Unable to connect. please contact the system administrator!", vbExclamation)
            cn.Close()
        End Try
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click



        cm.CommandText = "UPDATE student_details SET name = '" & TextBox1.Text & "', roll_no = '" & TextBox2.Text & "' ,degree_branch = '" & ComboBox1.SelectedItem & "',batch = '" & ComboBox2.SelectedItem & "', dob = '" & DateTimePicker1.Text & "', place_of_birth = '" & TextBox3.Text & "', first_graduate = '" & TextBox4.Text & "', tc_no = '" & TextBox5.Text & "', mother_tongue = '" & TextBox6.Text & "', relegion = '" & TextBox7.Text & "',   section = '" & TextBox8.Text & "', cut_off_mark = '" & TextBox9.Text & "',admission_no = '" & TextBox10.Text & "',date_of_joining = '" & DateTimePicker2.Text & "',category = '" & ComboBox3.SelectedItem & "',tc_date = '" & DateTimePicker3.Text & "', community = '" & TextBox11.Text & "', ph_no = '" & TextBox12.Text & "', identification_marks = '" & RichTextBox1.Text & "' , communication_address = '" & RichTextBox2.Text & "'  , mail_id = '" & TextBox13.Text & "', father_name = '" & TextBox14.Text & "' ,father_occupation = '" & TextBox15.Text & "',  father_ph_no = '" & TextBox16.Text & "', mother_name =  '" & TextBox17.Text & "', mother_ph_no = '" & TextBox18.Text & "' ,annual_income = '" & TextBox19.Text & "' WHERE roll_no = '" & TextBox2.Text & "' "
        cm.Connection = cn
        cm.ExecuteNonQuery()

        MsgBox("Details have Updated Successfully", vbInformation)

        TextBox1.Clear()
        TextBox2.Clear()
        ComboBox1.ResetText()
        ComboBox2.ResetText()

        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox10.Clear()
        RichTextBox1.Clear()
        RichTextBox2.Clear()

        ComboBox3.ResetText()

        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()
        TextBox16.Clear()
        TextBox17.Clear()
        TextBox18.Clear()
        TextBox19.Clear()

       
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        student_details.Show()
        Me.Close()

    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Dim OFD As FileDialog = New OpenFileDialog()

            OFD.Filter = "Image File (*.jpg;*bmp;*.gif;*.img)|*.jpg;*bmp;*.gif;*.img"

            If OFD.ShowDialog() = DialogResult.OK Then
                imgpath = OFD.FileName
                PictureBox1.ImageLocation = imgpath

            End If

            OFD = Nothing

        Catch ex As Exception
            MsgBox(ex.Message.ToString())
        End Try
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class