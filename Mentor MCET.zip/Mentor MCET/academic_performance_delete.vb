﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class academic_performance_delete
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim dt As New DataTable
    Dim bsource As New BindingSource

    Private Sub academic_performance_delete_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New MySqlConnection
        cm = New MySqlCommand
        cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
        cn.Open()
        cm.Connection = cn
        cm.CommandText = "select roll_no from student_details"
        dr = cm.ExecuteReader
        While dr.Read
            ComboBox1.Items.Add(dr.GetString(0))
        End While
        dr.Close()
        cn.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        cm.CommandText = "DELETE FROM `semester1` WHERE semester ='" & ComboBox2.SelectedItem & "'  roll_no = '" & ComboBox1.SelectedItem & "' and s_no = '" & TextBox1.Text & "' "

        cm.Connection = cn
        cm.ExecuteNonQuery()

        MsgBox("Details have Deleted Successfully", vbInformation)

        TextBox1.Clear()
        TextBox2.Clear()
        ComboBox1.ResetText()
        ComboBox2.ResetText()

        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()
        TextBox16.Clear()
        TextBox17.Clear()
        TextBox18.Clear()
        TextBox19.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        oinsert_student.Show()
        Me.Close()

    End Sub

End Class
