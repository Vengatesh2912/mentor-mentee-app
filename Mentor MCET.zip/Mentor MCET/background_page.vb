﻿Public Class background_page
   

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        login.Show()

    End Sub

    Private Sub background_page_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
