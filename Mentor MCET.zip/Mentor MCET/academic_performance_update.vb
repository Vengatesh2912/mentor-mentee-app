﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class academic_performance_update
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim dt As New DataTable
    Dim bsource As New BindingSource

    Private Sub academic_performance_update_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New MySqlConnection
        cm = New MySqlCommand
        cn.ConnectionString = "Server=db4free.net; port= 3306;User id = mentor1; Password = vengatesh ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
        cn.Open()
        cm.Connection = cn
        cm.CommandText = "select roll_no from student_details"

        dr = cm.ExecuteReader
        While dr.Read
            ComboBox1.Items.Add(dr.GetString(0))
        End While
       
        dr.Close()
        cn.Close()


    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cm.CommandText = "UPDATE `semester1` SET `course_name` = '" & TextBox2.Text & "' , `course_code`='" & TextBox3.Text & "',`ccet1_marks`='" & TextBox4.Text & "',`ccet2_marks`='" & TextBox5.Text & "',`ccet3_marks`='" & TextBox6.Text & "',`retest_mark`='" & TextBox7.Text & "',`internal_mark`=''" & TextBox8.Text & "',`ESE_grade`='" & TextBox9.Text & "',`month_and_year_of_passing`='" & DateTimePicker1.Text & "',`ccet1_attendance_percentage`='" & TextBox11.Text & "',`ccet2_attendance_percentage`=''" & TextBox12.Text & "'',`overall_attendance_percentage`='" & TextBox13.Text & "',`SGPA`='" & TextBox14.Text & "',`CGPA`='" & TextBox15.Text & "',`student_conduct`='" & TextBox16.Text & "',`mentor`='" & TextBox17.Text & "',`PC`='" & TextBox18.Text & "',`HOD`='" & TextBox19.Text & "' WHERE roll_no = '" & ComboBox1.SelectedItem & "' AND s_no = '" & TextBox1.Text & "' AND semester = '" & ComboBox2.SelectedItem & "'  "
        cm.Connection = cn
        cm.ExecuteNonQuery()

        MsgBox("Details have Updated Successfully", vbInformation)

        TextBox1.Clear()
        TextBox2.Clear()
        ComboBox1.ResetText()
        ComboBox2.ResetText()

        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox9.Clear()
        TextBox11.Clear()
        TextBox12.Clear()
        TextBox13.Clear()
        TextBox14.Clear()
        TextBox15.Clear()
        TextBox16.Clear()
        TextBox17.Clear()
        TextBox18.Clear()
        TextBox19.Clear()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        oinsert_student.Show()
        Me.Close()

    End Sub

End Class