﻿Public Class student_details

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        menuu.Show()
        Me.Close()
    End Sub

    Private Sub MenuToolStripMenuItem_Click(sender As Object, e As EventArgs)
        menuu.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        pinsert_student.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        pupdate_student1.Show()
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        pdelete_student1.Show()
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        pview_student.Show()
        Me.Close()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        oinsert_student.Show()
        Me.Close()
    End Sub

   
    Private Sub student_details_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class