﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class academic_performance_insert
    Dim cn As New MySqlConnection
    Dim cm As New MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim dv As DataView
    Dim drv As DataRowView
    Dim dt As New DataTable
    Dim bsource As New BindingSource

    Private Sub academic_performance_insert_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn = New MySqlConnection
        cm = New MySqlCommand
        cn.ConnectionString = "Server=db4free.net; port= 3306;User id = ; Password =  ; Database = mentor_mcet; connect timeout=100000000; pooling=true"
        cn.Open()
        cm.Connection = cn
        cm.CommandText = "select roll_no from student_details"
        dr = cm.ExecuteReader
        While dr.Read
            ComboBox1.Items.Add(dr.GetString(0))
        End While
        dr.Close()
        cn.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        oinsert_student.Show()
        Me.Close()

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try

            cn.Open()
            cm = New MySqlCommand("INSERT into " & ComboBox2.SelectedItem & " (`s_no`, `roll_no`,`semester`, `course_name`, `course_code`, `ccet1_marks`, `ccet2_marks`, `ccet3_marks`, `retest_mark`, `internal_mark`, `ESE_grade`, `month_and_year_of_passing`, `ccet1_attendance_percentage`, `ccet2_attendance_percentage`, `overall_attendance_percentage`, `SGPA`, `CGPA`, `student_conduct`, `mentor`, `PC`, `HOD`) VALUES ('" & TextBox1.Text & "','" & ComboBox1.SelectedItem & "','" & ComboBox2.SelectedItem & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" & DateTimePicker1.Text & "','" & TextBox11.Text & "','" & TextBox12.Text & "','" & TextBox13.Text & "','" & TextBox14.Text & "','" & TextBox15.Text & "','" & TextBox16.Text & "','" & TextBox17.Text & "','" & TextBox18.Text & "','" & TextBox19.Text & "')", cn)
            cm.ExecuteNonQuery()

            MsgBox("Details have Registered Successfully", vbInformation)

            ComboBox1.ResetText()
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
            TextBox8.Clear()
            TextBox9.Clear()
            TextBox11.Clear()
            TextBox12.Clear()
            TextBox13.Clear()
            TextBox14.Clear()
            TextBox15.Clear()
            TextBox16.Clear()
            TextBox17.Clear()
            TextBox18.Clear()
            TextBox19.Clear()
            ComboBox2.ResetText()

            cn.Close()
        Catch ex As Exception
            cn.Close()
            MsgBox(ex.Message, vbCritical)

        End Try
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub
End Class