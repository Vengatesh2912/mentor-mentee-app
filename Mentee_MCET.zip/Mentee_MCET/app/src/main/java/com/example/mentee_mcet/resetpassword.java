
package com.example.mentee_mcet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class resetpassword extends AppCompatActivity {
        TextView Login3;
        Button reset_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resetpassword);

        Login3 = findViewById(R.id.Login3);
        reset_password = findViewById(R.id.reset_password);

        reset_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://mcetmentor.000webhostapp.com/studentlogin/resetpassword1.html"));
                startActivity(browserIntent);
            }
        });

        Login3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(resetpassword.this, LoginActivity.class));
            }
        });
    }
}