package com.example.mentee_mcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.icu.text.UnicodeSetSpanner;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import android.widget.Toast;
import android.annotation.SuppressLint;
import android.view.View;
import android.widget.GridLayout;


import android.widget.TextView;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
   EditText mail_id1,password1;
    TextView forgotpassword1, register1 ,notwork;

   String str_mail_id1,str_password1;
    String url = "https://mcetmentor.000webhostapp.com/studentlogin/login2.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mail_id1 = findViewById(R.id.mail_id1);
        password1 = findViewById(R.id.password1);

        forgotpassword1 = findViewById(R.id.forgotpassword1);
        forgotpassword1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, resetpassword.class));
            }
        });
        register1 = findViewById(R.id.register1);
        register1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));

            }
        });
        notwork = findViewById(R.id.notwork);
        notwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, personal_details.class));
            }
        });

    }

    public void login1(View view) {

        if (mail_id1.getText().toString().equals("")){
            Toast.makeText(this, "Enter the Mail ID or User ID", Toast.LENGTH_SHORT).show();
        }
        else if (password1.getText().toString().equals("")){
            Toast.makeText(this,"Enter the Password", Toast.LENGTH_SHORT).show();
        }
        else {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Please Wait...");

            progressDialog.show();
            str_mail_id1 = mail_id1.getText().toString().trim();
            str_password1 = password1.getText().toString().trim();


            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    if (response.equalsIgnoreCase("Logged in Successfully")) {

                        mail_id1.setText("");
                        password1.setText("");
                        startActivity(new Intent(getApplicationContext(), academic_details.class));
                        Toast.makeText(LoginActivity.this, response, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, response, Toast.LENGTH_SHORT).show();

                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, error.getMessage().toString(),Toast.LENGTH_SHORT).show();
                }
            }
            ){
                @Override
                protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();

                    params.put("mail_id1",str_mail_id1);
                    params.put("password", str_password1);

                    return params;

                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);

            requestQueue.add(request);


        }

    }

}







