package com.example.mentee_mcet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class personal_details extends AppCompatActivity {

    Button extra_curricular2,update_profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_details);

        update_profile = findViewById(R.id.update_profile);

        update_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://mcetmentor.000webhostapp.com/studentlogin/insert_student.html"));
                startActivity(browserIntent);
            }
        });

        extra_curricular2= findViewById(R.id.extra_curricular2);

        extra_curricular2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://mcetmentor.000webhostapp.com/studentlogin/fetch_details.html"));
                startActivity(browserIntent);
            }
        });

    }
}