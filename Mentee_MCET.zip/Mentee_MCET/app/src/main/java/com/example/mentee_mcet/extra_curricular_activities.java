package com.example.mentee_mcet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class extra_curricular_activities extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extra_curricular_activities);
    }
}