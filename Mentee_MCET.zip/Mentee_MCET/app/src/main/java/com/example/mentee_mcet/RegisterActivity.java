package com.example.mentee_mcet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText mail_id, name, password, roll_no;
    String str_mail_id, str_name, str_password, str_roll_no;
    String url = "https://mcetmentor.000webhostapp.com/studentlogin/register1.php";
    TextView loginhere;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mail_id = findViewById(R.id.mail_id);
        name = findViewById(R.id.name);
        password = findViewById(R.id.password);
        roll_no = findViewById(R.id.roll_no);


        loginhere = findViewById(R.id.loginhere);
        loginhere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));

            }
        });
    }

    public void register(View view) {

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait...");

        if (mail_id.getText().toString().equals("")){
            Toast.makeText(this,"Enter your User or Mail ID ",Toast.LENGTH_SHORT).show();
        }
        else if (name.getText().toString().equals("")) {
            Toast.makeText(this,"Enter your Full Name ", Toast.LENGTH_SHORT).show();
        }
        else if (password.getText().toString().equals("")) {
            Toast.makeText(this,"Enter the Password", Toast.LENGTH_SHORT).show();
        }
        else if (roll_no.getText().toString().equals("")) {
            Toast.makeText(this,"Enter the Confirm Password", Toast.LENGTH_SHORT).show();
        }
        else {

            progressDialog.show();
            str_mail_id = mail_id.getText().toString().trim();
            str_name = name.getText().toString().trim();
            str_password = password.getText().toString().trim();
            str_roll_no = roll_no.getText().toString().trim();

            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    mail_id.setText("");
                    name.setText("");
                    password.setText("");
                    roll_no.setText("");


                    Toast.makeText(RegisterActivity.this, response, Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(RegisterActivity.this, error.getMessage().toString(),Toast.LENGTH_SHORT).show();
                }
            }
            ){
                @Override
                protected Map<String, String> getParams() throws com.android.volley.AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();

                    params.put("mail_id",str_mail_id);
                    params.put("name", str_name);
                    params.put("password", str_password);
                    params.put("confirm_password",str_roll_no);
                    return params;

                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(RegisterActivity.this);

            requestQueue.add(request);


        }
    }

}


